"""Sends an article to Gemini and gets a simple explanation back as JSON."""
import os
import json
import time
from google import genai
from google.genai import types, errors


class AIError(Exception):
    """Raised with a friendly message when Gemini fails."""


PROMPT = """You are a friendly teacher explaining financial news to a beginner with no finance knowledge.
Use short sentences and plain words.

Article title: {title}
Article description: {description}
Article content: {content}

Reply ONLY with JSON in exactly this shape:
{{
  "simple_summary": "2-3 easy sentences",
  "key_points": ["point 1", "point 2", "point 3"],
  "why_it_matters": "1-2 easy sentences",
  "terms": [{{"term": "Inflation", "meaning": "A general rise in prices."}}]
}}
Include 2-4 difficult financial terms from the article in "terms"."""


def simplify_article(title, description, content):
    key = os.getenv("GEMINI_API_KEY")
    if not key or key.startswith("your_"):
        raise AIError("GEMINI_API_KEY is missing. Add it to backend/.env and restart the server.")

    model = os.getenv("GEMINI_MODEL", "gemini-3.6-flash")
    prompt = PROMPT.format(title=title, description=description, content=content)

    client = genai.Client(api_key=key)
    # Gemini sometimes says "high demand" (503). That is temporary, so we retry a few times.
    for attempt in range(4):
        try:
            response = client.models.generate_content(
                model=model,
                contents=prompt,
                config=types.GenerateContentConfig(response_mime_type="application/json"),
            )
            return json.loads(response.text)
        except json.JSONDecodeError:
            raise AIError("The AI answered in an unexpected format. Please try again.")
        except errors.ServerError as e:
            if attempt < 3:
                time.sleep(2 * (attempt + 1))  # wait 2s, 4s, 6s then try again
                continue
            raise AIError("Gemini is very busy right now. Please wait a minute and click Simplify again.")
        except Exception as e:
            raise AIError("Gemini request failed: " + str(e))
