"""FinNews AI - FastAPI backend. Run from the project root:
    uvicorn backend.main:app --reload
"""
import os
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))  # load API keys from backend/.env

# Import after load_dotenv so the keys are available.
from backend.news_api import fetch_news, CATEGORY_QUERIES, NewsError
from backend.ai_summarizer import simplify_article, AIError

app = FastAPI(title="FinNews AI")

# CORS lets the frontend talk to the backend even if opened from another port (e.g. Live Server).
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


class ArticleIn(BaseModel):
    title: str
    description: str = ""
    content: str = ""


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/api/news")
def get_news(category: str = "markets"):
    query = CATEGORY_QUERIES.get(category.lower(), CATEGORY_QUERIES["markets"])
    try:
        return {"articles": fetch_news(query)}
    except NewsError as e:
        raise HTTPException(status_code=502, detail=str(e))


@app.get("/api/search")
def search_news(q: str = ""):
    if not q.strip():
        raise HTTPException(status_code=400, detail="Please type something to search for.")
    try:
        return {"articles": fetch_news(q.strip())}
    except NewsError as e:
        raise HTTPException(status_code=502, detail=str(e))


@app.post("/api/summarize")
def summarize(article: ArticleIn):
    try:
        return simplify_article(article.title, article.description, article.content)
    except AIError as e:
        raise HTTPException(status_code=502, detail=str(e))


# Serve the website at http://127.0.0.1:8000 (must be LAST so it doesn't hide /api routes).
app.mount("/", StaticFiles(directory=os.path.join(BASE_DIR, "..", "frontend"), html=True), name="frontend")
