"""Fetches news from NewsAPI. The API key stays here on the backend."""
import os
import requests

NEWS_URL = "https://newsapi.org/v2/everything"

# Each category button in the website maps to a NewsAPI search phrase.
CATEGORY_QUERIES = {
    "markets": "stock market OR shares OR Wall Street",
    "business": "business OR companies OR earnings",
    "economy": "economy OR inflation OR interest rates",
    "technology": "technology stocks OR tech industry",
    "global": "global economy OR world trade",
}


class NewsError(Exception):
    """Raised with a friendly message when something goes wrong."""


def fetch_news(query, page_size=12):
    key = os.getenv("NEWS_API_KEY")
    if not key or key.startswith("your_"):
        raise NewsError("NEWS_API_KEY is missing. Add it to backend/.env and restart the server.")

    params = {"q": query, "language": "en", "sortBy": "publishedAt", "pageSize": page_size}
    try:
        response = requests.get(NEWS_URL, params=params, headers={"X-Api-Key": key}, timeout=15)
        data = response.json()
    except (requests.RequestException, ValueError):
        raise NewsError("Could not reach NewsAPI. Check your internet connection and try again.")

    if response.status_code != 200 or data.get("status") != "ok":
        raise NewsError("NewsAPI error: " + str(data.get("message", "unknown error")))

    articles = []
    for a in data.get("articles", []):
        if not a.get("title") or a["title"] == "[Removed]":
            continue  # skip deleted articles
        articles.append({
            "title": a["title"],
            "description": a.get("description") or "",
            "content": a.get("content") or "",
            "source": (a.get("source") or {}).get("name", "Unknown"),
            "published_at": a.get("publishedAt", ""),
            "image": a.get("urlToImage") or "",
            "url": a.get("url", ""),
        })
    return articles
