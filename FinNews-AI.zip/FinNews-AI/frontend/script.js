// FinNews AI frontend. Talks only to our FastAPI backend (never directly to NewsAPI/Gemini).

// If the page is opened from the FastAPI server (port 8000) use relative URLs,
// otherwise (e.g. VS Code Live Server) point at the backend directly.
const API = location.port === "8000" ? "" : "http://127.0.0.1:8000";

const GLOSSARY = [
  ["Inflation", "A general rise in prices, so your money buys less than before."],
  ["GDP", "Gross Domestic Product: the total value of everything a country produces in a period."],
  ["Interest Rate", "The cost of borrowing money, shown as a percentage."],
  ["Recession", "A period when the economy shrinks, usually with job losses and less spending."],
  ["Bull Market", "A time when stock prices are rising and investors feel confident."],
  ["Bear Market", "A time when stock prices fall a lot (usually 20% or more)."],
  ["Stock", "A small piece of ownership in a company."],
  ["Bond", "A loan you give to a company or government that pays you back with interest."],
  ["Market Capitalization", "A company's total value: share price × number of shares."],
  ["Dividend", "A share of a company's profit paid to its shareholders."],
  ["IPO", "Initial Public Offering: when a company first sells its shares to the public."],
  ["ETF", "Exchange-Traded Fund: a basket of many investments you can buy as one share."],
];

let currentList = [];     // articles shown in the news grid
let savedList = [];       // articles shown in the saved grid
let currentArticle = null;
let currentCategory = "markets";

const $ = (id) => document.getElementById(id);

// Escape text before putting it in HTML (prevents broken/unsafe markup).
function esc(text) {
  return String(text || "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// Small helper: call the backend, return JSON, or throw a friendly Error.
async function callApi(path, options) {
  let response;
  try {
    response = await fetch(API + path, options);
  } catch (e) {
    throw new Error("Cannot reach the backend. Is uvicorn running?");
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.detail || "Something went wrong.");
  return data;
}

// ---------- Views ----------
function showView(name) {
  ["newsView", "detailView", "savedView"].forEach((id) => $(id).classList.add("hidden"));
  $(name).classList.remove("hidden");
  $(name).scrollIntoView({ behavior: "auto", block: "start" });
}

// ---------- News list ----------
function formatDate(iso) {
  return iso ? new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" }) : "";
}

function renderCards(list, grid) {
  grid.innerHTML = list.map((a, i) => `
    <div class="card">
      ${a.image ? `<img src="${esc(a.image)}" alt="" onerror="this.style.display='none'">` : ""}
      <div class="card-body">
        <h3 data-i="${i}" data-action="open">${esc(a.title)}</h3>
        <p class="meta">${esc(a.source)} · ${formatDate(a.published_at)}</p>
        <p>${esc(a.description)}</p>
        <button class="primary" data-i="${i}" data-action="simplify">Simplify News</button>
      </div>
    </div>`).join("");
}

async function loadNews(path, title) {
  $("newsTitle").textContent = title;
  $("newsGrid").innerHTML = "";
  $("newsMessage").className = "message";
  $("newsMessage").textContent = "Fetching latest news...";
  try {
    const data = await callApi(path);
    currentList = data.articles;
    if (currentList.length === 0) {
      $("newsMessage").textContent = "No articles found. Try a different search or category.";
      return;
    }
    $("newsMessage").textContent = "";
    renderCards(currentList, $("newsGrid"));
  } catch (e) {
    $("newsMessage").className = "message error";
    $("newsMessage").textContent = e.message;
  }
}

function loadCategory(cat) {
  currentCategory = cat;
  document.querySelectorAll("#categories button").forEach((b) =>
    b.classList.toggle("active", b.dataset.cat === cat));
  showView("newsView");
  loadNews("/api/news?category=" + cat, "Latest News: " + cat[0].toUpperCase() + cat.slice(1));
}

// Card clicks (works for both the news grid and the saved grid)
function handleCardClick(event, getList) {
  const el = event.target.closest("[data-action]");
  if (!el) return;
  const article = getList()[Number(el.dataset.i)];
  openDetail(article, el.dataset.action === "simplify");
}
$("newsGrid").addEventListener("click", (e) => handleCardClick(e, () => currentList));
$("savedGrid").addEventListener("click", (e) => handleCardClick(e, () => savedList));

// ---------- Article details + AI ----------
function openDetail(article, autoSimplify) {
  currentArticle = article;
  $("detailTitle").textContent = article.title;
  $("detailMeta").textContent = article.source + " · " + formatDate(article.published_at);
  $("detailText").textContent = article.description || article.content || "No preview text available.";
  $("detailImage").style.display = article.image ? "block" : "none";
  $("detailImage").src = article.image || "";
  $("readBtn").href = article.url;
  $("aiResult").classList.add("hidden");
  $("aiMessage").textContent = "";
  $("aiMessage").className = "message";
  updateSaveButton();
  showView("detailView");
  if (autoSimplify) simplifyCurrent();
}

async function simplifyCurrent() {
  $("aiResult").classList.add("hidden");
  $("aiMessage").className = "message";
  $("aiMessage").textContent = "AI is simplifying this article...";
  try {
    const r = await callApi("/api/summarize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: currentArticle.title,
        description: currentArticle.description,
        content: currentArticle.content,
      }),
    });
    $("aiMessage").textContent = "";
    $("aiResult").innerHTML = `
      <h4>Simple Summary</h4><p>${esc(r.simple_summary)}</p>
      <h4>Key Points</h4><ul>${(r.key_points || []).map((p) => `<li>${esc(p)}</li>`).join("")}</ul>
      <h4>Why It Matters</h4><p>${esc(r.why_it_matters)}</p>
      <h4>Financial Terms</h4>
      <ul>${(r.terms || []).map((t) => `<li><b>${esc(t.term)}</b> → ${esc(t.meaning)}</li>`).join("")}</ul>`;
    $("aiResult").classList.remove("hidden");
  } catch (e) {
    $("aiMessage").className = "message error";
    $("aiMessage").textContent = e.message;
  }
}

// ---------- Saved articles (localStorage) ----------
function getSaved() {
  try { return JSON.parse(localStorage.getItem("savedArticles")) || []; } catch (e) { return []; }
}
function setSaved(list) {
  localStorage.setItem("savedArticles", JSON.stringify(list));
  $("savedCount").textContent = list.length;
}
function isSaved(article) { return getSaved().some((a) => a.url === article.url); }

function updateSaveButton() {
  $("saveBtn").textContent = isSaved(currentArticle) ? "Remove from Saved" : "Save Article";
}

function toggleSave() {
  let list = getSaved();
  if (isSaved(currentArticle)) list = list.filter((a) => a.url !== currentArticle.url);
  else list.push(currentArticle);
  setSaved(list);
  updateSaveButton();
}

function showSaved() {
  savedList = getSaved();
  $("savedMessage").textContent = savedList.length ? "" : "No saved articles yet. Open an article and click Save Article.";
  renderCards(savedList, $("savedGrid"));
  showView("savedView");
}

// ---------- Setup ----------
$("categories").addEventListener("click", (e) => {
  if (e.target.dataset.cat) loadCategory(e.target.dataset.cat);
});
$("searchForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const q = $("searchInput").value.trim();
  if (!q) return;
  document.querySelectorAll("#categories button").forEach((b) => b.classList.remove("active"));
  showView("newsView");
  loadNews("/api/search?q=" + encodeURIComponent(q), 'Results for "' + q + '"');
});
$("simplifyBtn").addEventListener("click", simplifyCurrent);
$("saveBtn").addEventListener("click", toggleSave);
$("backBtn").addEventListener("click", () => showView("newsView"));
$("navHome").addEventListener("click", () => loadCategory(currentCategory));
$("navSaved").addEventListener("click", showSaved);

$("glossaryGrid").innerHTML = GLOSSARY.map(
  ([term, meaning]) => `<div class="term"><h3>${esc(term)}</h3><p>${esc(meaning)}</p></div>`).join("");

setSaved(getSaved());   // updates the saved counter in the navbar
loadCategory("markets");
