@echo off
cd /d "%~dp0"
echo ===== FinNews AI =====

REM Step 1: if the .env file still has placeholder keys, open it so you can paste your real keys
findstr /C:"your_" backend\.env >nul
if %errorlevel%==0 (
  echo.
  echo Paste your NewsAPI and Gemini keys after the = signs, save the file, then close Notepad.
  notepad backend\.env
)

REM Step 2: install the Python packages (only slow the first time)
echo Installing packages...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Package install failed. Copy the error above and send it to me.
  pause
  exit /b 1
)

REM Step 3: open the browser and start the server
echo.
echo Starting server. Keep this window open. Press Ctrl+C to stop.
start "" http://127.0.0.1:8000
python -m uvicorn backend.main:app --reload
pause
