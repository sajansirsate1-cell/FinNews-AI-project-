# FinNews AI – Financial News Simplifier

**Complex Financial News Made Simple.** FinNews AI shows the latest financial news and uses Google Gemini to explain any article in plain English, with key points and jargon explained.

## Quick start (Windows)
1. Extract the ZIP to a NEW folder (e.g. Desktop) and open it so you can see `run.bat`.
2. Double-click **run.bat**. Notepad opens `backend/.env`: paste your two API keys after the `=` signs, save, close Notepad.
3. The script installs everything, starts the server and opens http://127.0.0.1:8000.

## Features
- Latest news dashboard with categories: Markets, Business, Economy, Technology, Global
- Search (e.g. "Tesla", "Bitcoin", "Indian economy")
- Article details page with "Read Original Article" (opens in a new tab)
- AI simplification: summary, key points, why it matters, financial terms explained
- Financial glossary (12 common terms)
- Save / remove articles (stored in your browser's localStorage)
- Loading states, friendly error messages, responsive layout

## Tech stack
- Frontend: HTML, CSS, vanilla JavaScript
- Backend: Python + FastAPI (uses `requests` for NewsAPI, `google-genai` for Gemini)
- API keys live only in the backend `.env` file

## Folder structure
```
FinNews-AI/
├── backend/
│   ├── main.py            # FastAPI app + endpoints
│   ├── news_api.py        # talks to NewsAPI
│   ├── ai_summarizer.py   # talks to Gemini
│   └── .env.example       # copy this to .env
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── requirements.txt
├── .gitignore
└── README.md
```

## Setup (in the VS Code terminal)
Open the `FinNews-AI` folder in VS Code (File → Open Folder), then open a terminal (Ctrl+`). You need Python 3.9+.

1. (Recommended) create a virtual environment:
   - Windows: `python -m venv venv` then `venv\Scripts\activate`
   - Mac/Linux: `python3 -m venv venv` then `source venv/bin/activate`
2. Install dependencies: `pip install -r requirements.txt`
3. Create your `.env` file:
   - Windows: `copy backend\.env.example backend\.env`
   - Mac/Linux: `cp backend/.env.example backend/.env`
4. Open `backend/.env` and paste your keys (no quotes, no spaces):
   ```
   NEWS_API_KEY=abc123...
   GEMINI_API_KEY=xyz789...
   ```

## Get your API keys
- **NewsAPI** (free): https://newsapi.org/register
- **Gemini** (free tier): https://aistudio.google.com/apikey

## Run it
From the project root (the `FinNews-AI` folder, not inside `backend`):
```
uvicorn backend.main:app --reload
```
Then open **http://127.0.0.1:8000** in your browser. FastAPI serves the website and the API together, so there is nothing else to start.
(Interactive API docs: http://127.0.0.1:8000/docs)

Optional: you can also open `frontend/index.html` with the VS Code Live Server extension; the backend must still be running.

## Example API usage
```
GET  http://127.0.0.1:8000/api/health
GET  http://127.0.0.1:8000/api/news?category=economy
GET  http://127.0.0.1:8000/api/search?q=bitcoin
POST http://127.0.0.1:8000/api/summarize
     {"title": "Fed signals rate cut", "description": "...", "content": "..."}
```

## Common errors and fixes
| Problem | Fix |
|---|---|
| `NEWS_API_KEY is missing` / `GEMINI_API_KEY is missing` | Create `backend/.env` (step 3–4) and restart uvicorn |
| `ModuleNotFoundError: No module named 'backend'` | Run uvicorn from the project root, not from inside `backend/` |
| `uvicorn is not recognized` | Activate your venv, or run `python -m uvicorn backend.main:app --reload` |
| `Cannot reach the backend` in the browser | Start uvicorn, and open http://127.0.0.1:8000 |
| NewsAPI `apiKeyInvalid` | Re-copy the key from your NewsAPI account |
| NewsAPI `rateLimited` | The free plan has a daily limit; try again later |
| Gemini request failed (404 model) | Set `GEMINI_MODEL` in `.env` to a currently available model from https://ai.google.dev/gemini-api/docs/models |
| Gemini quota / 429 error | Wait a minute and retry (free tier limits) |
| NewsAPI free plan on a deployed site | Free NewsAPI keys only work for local development |
